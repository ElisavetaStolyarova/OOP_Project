﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace TEST
{
    internal class Program
    {

    }
    public class AccountFrozenError : Exception { public AccountFrozenError() : base("Счет заморожен!") { } }
    public class AccountClosedError : Exception { public AccountClosedError() : base("Счет закрыт!") { } }
    public class InvalidOperationError : Exception { public InvalidOperationError(string m) : base(m) { } }
    public class InsufficientFundsError : Exception { public InsufficientFundsError() : base("Недостаточно средств!") { } }

    public enum Status { Active, Frozen, Closed }
    public enum Currency { RUB, USD, EUR, KZT, CNY }

    public abstract class AbstractAccount
    {
        public string Id { get; protected set; }
        public string Owner { get; protected set; }
        protected decimal balance;
        public Status AccStatus { get; set; } = Status.Active;

        public abstract void Deposit(decimal amount);
        public abstract void Withdraw(decimal amount);
        public abstract string GetAccountInfo();
    }

    public class BankAccount : AbstractAccount
    {
        public Currency Curr { get; private set; }

        public BankAccount(string owner, decimal startBalance, Currency curr, string id = null)
        {
            if (string.IsNullOrEmpty(owner) || startBalance < 0)
                throw new InvalidOperationError("Ошибка: Неверное имя или баланс!");

            Owner = owner;
            balance = startBalance;
            Curr = curr;
            Id = id ?? Guid.NewGuid().ToString().Substring(0, 8).ToUpper();
        }

        private void CheckStatus()
        {
            if (AccStatus == Status.Frozen) throw new AccountFrozenError();
            if (AccStatus == Status.Closed) throw new AccountClosedError();
        }

        public override void Deposit(decimal amount)
        {
            CheckStatus();
            if (amount <= 0) throw new InvalidOperationError("Сумма должна быть > 0");
            balance += amount;
        }

        public override void Withdraw(decimal amount)
        {
            CheckStatus();
            if (amount <= 0 || amount > balance) throw new InsufficientFundsError();
            balance -= amount;
        }

        public override string GetAccountInfo()
        {
            string last4 = Id.Length >= 4 ? Id.Substring(Id.Length - 4) : Id;
            return $"[Тип: Банковский] [Клиент: {Owner}] [ID: ****{last4}] [Статус: {AccStatus}] [Баланс: {balance} {Curr}]";
        }

        public override string ToString() => GetAccountInfo();
        static void Main(string[] args)
        {
            var active = new BankAccount("Иван", 1000, Currency.RUB);
            var frozen = new BankAccount("Анна", 5000, Currency.USD) { AccStatus = Status.Frozen };

            Console.WriteLine("Созданы счета:\n" + active + "\n" + frozen);

            Console.WriteLine("\nТест: Операции на активном счете...");
            active.Deposit(500);
            active.Withdraw(200);
            Console.WriteLine("Итог: " + active);

            Console.WriteLine("\nТест: Снятие с замороженного счета...");
            try { frozen.Withdraw(100); }
            catch (Exception ex) { Console.WriteLine("Результат: " + ex.Message); }
        }
    } 
}


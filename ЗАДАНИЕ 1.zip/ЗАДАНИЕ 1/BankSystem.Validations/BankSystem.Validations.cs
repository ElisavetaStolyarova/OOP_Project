﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem.Validations
{
    internal class Program
    {
        
        public class AccountFrozenError : Exception { public AccountFrozenError() : base("Счет заморожен.") { } }
        public class AccountClosedError : Exception { public AccountClosedError() : base("Счет закрыт.") { } }
        public class InvalidOperationError : Exception { public InvalidOperationError(string m) : base(m) { } }
        public class InsufficientFundsError : Exception { public InsufficientFundsError() : base("Недостаточно средств.") { } }

        public enum AccountStatus { Active, Frozen, Closed }

        public class ValidationDemo
        {
            private decimal _balance = 1000;
            private AccountStatus _status = AccountStatus.Active;

            public void ProcessTransaction(decimal amount, bool isWithdrawal)
            {
                Console.WriteLine($"--- Обработка операции: {(isWithdrawal ? "Снятие" : "Пополнение")} {amount} ---");

                if (_status == AccountStatus.Frozen) throw new AccountFrozenError();
                if (_status == AccountStatus.Closed) throw new AccountClosedError();

                if (amount <= 0)
                {
                    throw new InvalidOperationError("Сумма должна быть больше нуля. Отрицательные значения запрещены.");
                }

                if (isWithdrawal)
                {
                    if (amount > _balance) throw new InsufficientFundsError();
                    _balance -= amount;
                }
                else
                {
                    _balance += amount;
                }

                Console.WriteLine($"Успешно! Новый баланс: {_balance}");
            }

            public void SetStatus(AccountStatus newStatus) => _status = newStatus;
        }
        static void Main(string[] args)
        {
            ValidationDemo bank = new ValidationDemo();

            try { bank.ProcessTransaction(-50, false); }
            catch (Exception ex) { Console.WriteLine($"Ошибка: {ex.Message}"); }

            try { bank.ProcessTransaction(0, false); }
            catch (Exception ex) { Console.WriteLine($"Ошибка: {ex.Message}"); }

            try
            {
                bank.SetStatus(AccountStatus.Frozen);
                bank.ProcessTransaction(100, false);
            }
            catch (Exception ex) { Console.WriteLine($"Ошибка: {ex.Message}"); }

            Console.WriteLine("\nПроверка завершена.");
        }
    }
}

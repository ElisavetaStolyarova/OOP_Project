﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractAccount
{
    
        public enum AccountStatus
    {
        Active,     
        Frozen,     
        Closed       
    }

    public abstract class AbstractAccount
    {
        public string Id { get; protected set; }

        public string OwnerName { get; protected set; }

        protected decimal balance;

        public AccountStatus Status { get; set; }

        public AbstractAccount(string id, string owner, decimal initialBalance)
        {
            Id = id;
            OwnerName = owner;
            balance = initialBalance;
            Status = AccountStatus.Active; 
        }
        public abstract void Deposit(decimal amount);   
        public abstract void Withdraw(decimal amount); 
        public abstract string GetAccountInfo();        
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Класс AbstractAccount создан.");
            
        }
    }
}

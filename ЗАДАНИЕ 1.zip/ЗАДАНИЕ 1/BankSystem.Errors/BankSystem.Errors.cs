﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem.Errors
{

    public class AccountFrozenError : Exception
    {
        public AccountFrozenError() : base("Операция отклонена: Счет заморожен.") { }
        public AccountFrozenError(string message) : base(message) { }
    }

    public class AccountClosedError : Exception
    {
        public AccountClosedError() : base("Операция невозможна: Счет закрыт.") { }
        public AccountClosedError(string message) : base(message) { }
    }

    public class InvalidOperationError : Exception
    {
        public InvalidOperationError() : base("Ошибка: Некорректная операция.") { }
        public InvalidOperationError(string message) : base(message) { }
    }
    public class InsufficientFundsError : Exception
    {
        public InsufficientFundsError() : base("Ошибка: Недостаточно средств на счете.") { }
        public InsufficientFundsError(string message) : base(message) { }
    
    static void Main(string[] args)
        {
            Console.WriteLine("--- Тестирование пользовательских ошибок ---");

            try
            {
                throw new InsufficientFundsError("Баланс: 0. Попытка снять: 100.");
            }
            catch (InsufficientFundsError ex)
            {
                Console.WriteLine($"Исключение: {ex.Message}");
            }

            try
            {
                throw new AccountFrozenError();
            }
            catch (AccountFrozenError ex)
            {
                Console.WriteLine($"Исключение: {ex.Message}");
            }

            Console.WriteLine("\nВсе классы ошибок успешно инициализированы.");
        }
    } }

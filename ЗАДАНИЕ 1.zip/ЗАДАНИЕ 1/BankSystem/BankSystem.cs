﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem
{
    internal class Program
    {
       
        public enum AccountStatus { Active, Frozen, Closed }
        public enum Currency { RUB, USD, EUR, KZT, CNY }

        public abstract class AbstractAccount
        {
            public string Id { get; protected set; }
            public string OwnerName { get; protected set; }
            protected decimal balance;
            public AccountStatus Status { get; set; }

            public abstract void Deposit(decimal amount);
            public abstract void Withdraw(decimal amount);
            public abstract string GetAccountInfo();
        }
        public class BankAccount : AbstractAccount
        {
            public Currency AccountCurrency { get; private set; }

            public BankAccount(string owner, decimal initialBalance, Currency currency, string id = null)
            {
                if (string.IsNullOrWhiteSpace(owner))
                    throw new Exception("Имя владельца не может быть пустым.");

                if (initialBalance < 0)
                    throw new Exception("Баланс не может быть отрицательным.");

                OwnerName = owner;
                balance = initialBalance;
                AccountCurrency = currency;
                Status = AccountStatus.Active;
                Id = string.IsNullOrEmpty(id)
                    ? Guid.NewGuid().ToString().Substring(0, 6).ToUpper()
                    : id;
            }

            private void ValidateOperation()
            {
                if (Status == AccountStatus.Frozen)
                    throw new Exception("Счет заморожен! Операция отклонена.");
                if (Status == AccountStatus.Closed)
                    throw new Exception("Счет закрыт! Операция невозможна.");
            }

            public override void Deposit(decimal amount)
            {
                ValidateOperation(); 
                if (amount <= 0) throw new Exception("Сумма должна быть положительной.");

                balance += amount;
                Console.WriteLine($"Зачислено {amount} {AccountCurrency}.");
            }

            public override void Withdraw(decimal amount)
            {
                ValidateOperation(); 
                if (amount <= 0) throw new Exception("Сумма должна быть положительной.");
                if (amount > balance) throw new Exception("Недостаточно средств.");

                balance -= amount;
                Console.WriteLine($"Снято {amount} {AccountCurrency}.");
            }

            public override string GetAccountInfo()
            {
                return $"ID: {Id} | Владелец: {OwnerName} | Баланс: {balance} {AccountCurrency} | Статус: {Status}";
            }
        }
        static void Main(string[] args)
        {
            try
            {

                BankAccount myAcc = new BankAccount("Иван Иванов", 1000, Currency.RUB);
                Console.WriteLine("Создан счет: " + myAcc.GetAccountInfo());

                myAcc.Deposit(500);


                myAcc.Status = AccountStatus.Frozen;
                Console.WriteLine("\nСтатус изменен на Frozen.");
                myAcc.Withdraw(100); 
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }


            Console.ReadKey();
        }
    }
}

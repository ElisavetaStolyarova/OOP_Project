﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace AccountInfo
{
    internal class Program
    {
        
        public class AccountFrozenError : Exception { public AccountFrozenError() : base("Счет заморожен!") { } }
        public class AccountClosedError : Exception { public AccountClosedError() : base("Счет закрыт!") { } }
        public class InvalidOperationError : Exception { public InvalidOperationError(string m) : base(m) { } }
        public class InsufficientFundsError : Exception { public InsufficientFundsError() : base("Недостаточно средств!") { } }

        public enum Status { Active, Frozen, Closed }
        public enum Currency { RUB, USD, EUR, KZT, CNY }

        public abstract class AbstractAccount
        {
            public string Id { get; protected set; }
            public string Owner { get; protected set; }
            protected decimal balance;
            public Status AccStatus { get; set; } = Status.Active;

            public abstract void Deposit(decimal amount);
            public abstract void Withdraw(decimal amount);
            public abstract string GetAccountInfo();
        }
        public class BankAccount : AbstractAccount
        {
            public Currency Curr { get; private set; }

            public BankAccount(string owner, decimal startBalance, Currency curr, string id = null)
            {
                if (string.IsNullOrEmpty(owner)) throw new InvalidOperationError("Имя не может быть пустым!");
                if (startBalance < 0) throw new InvalidOperationError("Начальный баланс не может быть < 0!");

                Owner = owner;
                balance = startBalance;
                Curr = curr;
                Id = id ?? Guid.NewGuid().ToString().Substring(0, 6).ToUpper();
            }

            private void CheckStatus()
            {
                if (AccStatus == Status.Frozen) throw new AccountFrozenError();
                if (AccStatus == Status.Closed) throw new AccountClosedError();
            }

            public override void Deposit(decimal amount)
            {
                CheckStatus();
                if (amount <= 0) throw new InvalidOperationError("Сумма пополнения должна быть > 0");
                balance += amount;
            }

            public override void Withdraw(decimal amount)
            {
                CheckStatus();
                if (amount <= 0) throw new InvalidOperationError("Сумма снятия должна быть > 0");
                if (amount > balance) throw new InsufficientFundsError();
                balance -= amount;
            }
            public override string GetAccountInfo()
            {
                string last4 = Id.Length >= 4 ? Id.Substring(Id.Length - 4) : Id;
                return $"1. Тип счета: Банковский счет\n" +
                       $"2. Клиент:    {Owner}\n" +
                       $"3. Номер ID:  ****{last4}\n" +
                       $"4. Статус:    {AccStatus}\n" +
                       $"5. Баланс:    {balance} {Curr}";
            }

            public override string ToString() => GetAccountInfo();
        }
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine(">>> ТЕСТ 1: Активный счет");
                var acc = new BankAccount("Иван Иванов", 1000, Currency.RUB);
                acc.Deposit(500);
                Console.WriteLine(acc); 

                Console.WriteLine("\n>>> ТЕСТ 2: Замороженный счет");
                acc.AccStatus = Status.Frozen;
                acc.Withdraw(100); 
            }
            catch (Exception ex)
            {
                Console.WriteLine("ОШИБКА: " + ex.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumAccount
{
    internal class Program
    {
        public class PremiumAccount
    {
        public string AccountId { get; set; }
        public string Owner { get; set; }
        public double Balance { get; set; }
        public double OverdraftLimit { get; set; }
        public double Commission { get; set; }    

        public PremiumAccount(string id, string owner, double balance, double limit, double comm)
        {
            AccountId = id;
            Owner = owner;
            Balance = balance;
            OverdraftLimit = limit;
            Commission = comm;
        }
        public bool Withdraw(double amount)
        {
            double total = amount + Commission;
            if (Balance - total >= -OverdraftLimit)
            {
                Balance -= total;
                return true;
            }
            Console.WriteLine("Ошибка: превышен лимит овердрафта.");
            return false;
        }
        public string Get_account_info()
        {
            return $"[Premium] ID: {AccountId}, Баланс: {Balance}, Овердрафт: {OverdraftLimit}";
        }

        public override string ToString() => $"PremiumAccount:{AccountId}:{Balance}";

}
        static void Main(string[] args)
        {
            PremiumAccount p = new PremiumAccount("PA01", "Anna", 500, 1000, 50);
            Console.WriteLine(p.Get_account_info());
            p.Withdraw(1000); 
            Console.WriteLine($"Баланс после снятия: {p.Balance}");

        }
    }
}

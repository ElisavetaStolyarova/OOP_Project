﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SavingAccount
{
    internal class Program
    {
        public class SavingAccounts
        {
            public string AccountId { get; set; }
            public string Owner { get; set; }
            public double Balance { get; set; }
            public double Min_balance { get; set; }
            public double MonthlyRate { get; set; }

            public SavingAccount(string id, string owner, double balance, double minBalance, double rate)
            {
                AccountId = id;
                Owner = owner;
                Balance = balance;
                Min_balance = minBalance;
                MonthlyRate = rate;s
            }
            public double CalculateProfit() => Balance * MonthlyRate;
            public bool Withdraw(double amount)
            {
                if (Balance - amount >= Min_balance)
                {
                    Balance -= amount;
                    return true;
                }
                Console.WriteLine("Ошибка: нарушение лимита минимального остатка.");
                return false;
            }
            public string Get_account_info()
            {
                return $"[Saving] ID: {AccountId}, Владелец: {Owner}, Баланс: {Balance}, Ставка: {MonthlyRate * 100}%";
            }
            public override string ToString() => $"SavingAccount:{AccountId}:{Balance}";


            static void Main(string[] args)
            {
                SavingAccount s = new SavingAccount("SA01", "Ivan", 1000, 200, 0.05);
                Console.WriteLine(s.Get_account_info());
                s.Withdraw(900); // Ошибка, остаток стал бы 100 < 200
                Console.WriteLine($"Прибыль: {s.CalculateProfit()}");

            }
        }
    }
}

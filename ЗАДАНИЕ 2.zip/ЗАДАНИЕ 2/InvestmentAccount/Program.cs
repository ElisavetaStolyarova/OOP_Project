﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InvestmentAccount
{
    internal class Program
    {
        public class InvestmentAccount
    {
        public string AccountId { get; set; }
        public string Owner { get; set; }
        public double Balance { get; set; }
        public List<(string Name, double Value, double Yield)> Portfolio = new List<(string, double, double)>();

        public InvestmentAccount(string id, string owner, double balance)
        {
            AccountId = id;
            Owner = owner;
            Balance = balance;
        }

        public double project_yearly_prowth()
        {
            double total = 0;
            foreach (var asset in Portfolio) total += asset.Value * asset.Yield;
            return total;
        }
        public bool Withdraw(double amount)
        {
            if (amount <= Balance)
            {
                Balance -= amount;
                return true;
            }
            return false;
        }
        public string Get_account_info()
        {
            return $"[Invest] ID: {AccountId}, Свободный баланс: {Balance}, Активов: {Portfolio.Count}";
        }
        public override string ToString() => $"InvestmentAccount:{AccountId}:{Portfolio.Count} assets";
        }
        static void Main(string[] args)
        {
            InvestmentAccount i = new InvestmentAccount("IA01", "Petr", 5000);
            i.Portfolio.Add(("Tesla Stock", 2000, 0.15));
            i.Portfolio.Add(("Gold ETF", 3000, 0.05));

            Console.WriteLine(i.Get_account_info());
            Console.WriteLine($"Ожидаемый годовой доход: {i.project_yearly_prowth()}");

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBankApp
{
    internal class Clients
    {
        public class Client
        {
            public string FIO { get; set; }
            public int Id { get; set; }
            public string Status { get; set; }
            public List<string> AccountNumbers { get; set; } = new List<string>();  
            public string Contacts { get; set; }
            public int Age { get; set; }
            public int LoginAttempts { get; set; } = 0; 

            public Client(string fio, int id, int age, string contacts)
            {
                if (age < 18) throw new Exception("Клиент должен быть старше 18 лет!");
                FIO = fio;
                Id = id;
                Age = age;
                Contacts = contacts;
                Status = "Active";
            }

            public override string ToString() => $"Клиент: {FIO}, Статус: {Status}";
}
        static void Main(string[] args)
        {
            try
            {
                Client c = new Client("Иванов И.И.", 1, 20, "mail@test.com");
                Console.WriteLine(c.ToString());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBankApp

{
    internal class Program
    {
        public class Bank
        {
            private List<Client> clients = new List<Client>();
            private List<string> frozenAccounts = new List<string>();


            public void add_client(Client client) => clients.Add(client);

            public void open_account(int clientId, string accNumber)
            {
                var client = clients.FirstOrDefault(c => c.Id == clientId);
                if (client != null) client.AccountNumbers.Add(accNumber);
            }
            public bool authenticate_client(int clientId, string password)
            {
                var client = clients.FirstOrDefault(c => c.Id == clientId);
                if (client == null || client.Status == "Blocked") return false;

                if (password == "1234")
                {
                    client.LoginAttempts = 0;
                    return true;
                }
                else
                {
                    client.LoginAttempts++;
                    if (client.LoginAttempts >= 3)
                    {
                        client.Status = "Blocked";
                        Console.WriteLine($"Клиент {client.FIO} заблокирован за 3 неверные попытки!");
                    }
                    return false;
                }
            }

            public void check_operation(double amount)
            {
                if (amount > 50000) Console.WriteLine("ВНИМАНИЕ: Подозрительная операция на большую сумму!");
            }
            public void send_message(string msg)
            {
                int hour = DateTime.Now.Hour;
                if (hour >= 0 && hour < 5)
                {
                    Console.WriteLine("Ошибка: Отправка сообщений запрещена с 00:00 до 05:00.");
                }
                else
                {
                    Console.WriteLine("Сообщение отправлено: " + msg);
                }
            }
            public void freeze_account(string accNumber) => frozenAccounts.Add(accNumber);

            public void unfreeze_account(string accNumber) => frozenAccounts.Remove(accNumber);

        }
        static void Main(string[] args)
        {
            Bank myBank = new Bank();
            Client c = new Client("Петров П.П.", 101, 25, "555-0101");
            myBank.add_client(c);
            myBank.open_account(101, "ACC_999");
            myBank.authenticate_client(101, "wrong");
            myBank.authenticate_client(101, "wrong");
            myBank.authenticate_client(101, "wrong");

            myBank.check_operation(100000);
            myBank.send_message("Ваш баланс обновлен");
        }
    }
}
